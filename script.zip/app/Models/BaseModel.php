<?php


namespace App\Models;

use Froiden\RestAPI\ApiModel;

class BaseModel extends ApiModel
{

}
